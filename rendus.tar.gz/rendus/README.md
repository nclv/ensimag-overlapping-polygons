Mieux qu'un fichier pdf. Un fichier HTML avec images et illustrations !!
Il est toujours possible de le convertir en pdf avec votre navigateur.

En espérant que vous apprécierez ce travail,

VINCENT Nicolas
ARGENTO Adrien